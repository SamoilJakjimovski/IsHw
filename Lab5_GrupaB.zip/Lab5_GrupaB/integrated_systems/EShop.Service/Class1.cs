﻿namespace EShop.Service
{
    public class Class1
    {

    }
}
